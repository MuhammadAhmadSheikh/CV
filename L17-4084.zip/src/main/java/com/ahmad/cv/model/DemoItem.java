package com.ahmad.cv.model;

public class DemoItem {
    private String title;


    public DemoItem(String title) {
        this.title = title;
    }

}
